package com.example.monzoo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class Jeu extends AppCompatActivity {

    public ImageButton boutonSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jeu);
        boutonSkip = (ImageButton) findViewById(R.id.boutonSkip);
        boutonSkip.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                ouvrirWin();
            }
        });
    }

    private void ouvrirWin() {
        Intent intent = new Intent(this, Win.class);
        startActivity(intent);
    }
}
